<?php
error_reporting(0);
date_default_timezone_set('Asia/Kolkata');

function connect_database() {
	$fetchType = "array";
	$dbHost    = "legendpa_getway";
	$dbLogin   = "legendpa_getway";
	$dbPwd     = "legendpa_getway";
	$dbName    = "legendpa_getway";
	$con       = mysqli_connect($dbHost, $dbLogin, $dbPwd, $dbName);
	if (!$con) {
		die("Database Connection failes" . mysqli_connect_errno());
	}
	return ($con);
}

// Database configuration
define('DB_HOST', 'legendpa_getway');
define('DB_USERNAME', 'legendpa_getway');
define('DB_PASSWORD', 'legendpa_getway');
define('DB_NAME', 'legendpa_getway');
?>