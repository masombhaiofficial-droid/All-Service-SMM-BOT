
<!DOCTYPE html>
<html lang="en-US" dir="ltr">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>SmartUPI -  Dynamic QR Code Generator API</title>
    <link rel="icon" type="image/png" href="https://smartupi.in/auth/assets/img/SmartUPI-Small-Logo.png" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&amp;family=Volkhov:wght@700&amp;display=swap" rel="stylesheet" />
    <link href="https://smartupi.in/home/assets/css/theme.css" rel="stylesheet" />
<style type="text/css">
.plan-box {
    background-color: transparent;
    box-shadow: 0px 1px 15px 1px rgb(69 65 78 / 8%);
    border: none;
}  

.btn-check:focus + .btn-primary, .btn-primary:focus {
    color: #FFFEFE;
    background-color: #066ede;
    border-color: #066ede;
}

.btn-primary:hover {
    color: #FFFEFE;
    background-color: #066ede;
    border-color: #066ede;
}

.btn-primary {
    color: #FFFEFE;
    background-color: #007bff;
    border-color: #007bff;
}
.text-primary {
    color: #007bff !important;
}
.btn-check:checked + .btn-outline-primary, .btn-check:active + .btn-outline-primary, .btn-outline-primary:active, .btn-outline-primary.active, .btn-outline-primary.dropdown-toggle.show {
    color: #FFFEFE;
    background-color: #007bff;
    border-color: #007bff;
}
.btn-outline-primary:hover {
    color: #FFFEFE;
    background-color: #007bff;
    border-color: #007bff;
}
.btn-outline-primary {
    color: #007bff;
    border-color: #007bff;
}
.modal-content {
    border-radius: 0.5rem;
}

.text-dark {
    color: #000000 !important;
}

.btn-dark {
    color: #FFFEFE;
    background-color: #000000;
    border-color: #000000;
}

.bg-dark {
    color: #FFFEFE !important;
    background-color: #000000 !important;
    border-color: #000000 !important;
}
</style>    
</head>

<body>
<!-- Modal -->
<div class="modal fade" id="disclaimer" tabindex="-1" aria-labelledby="Disclaimer" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-danger" id="Disclaimer">❗ Disclaimer</h5>
      </div>
      <div class="modal-body">
		  <p>The SmartUPI does not provide any payment gateway services,  accounts, or  merchant accounts.</p>
		  <p>We only provide an API to generate a QR code for your  ID.</p>
		  <p>We are not involved in any kind of transaction. Please read our terms and conditions before using our service.</p>
	  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-dark btn-sm" onclick="$('body').html('');">Leave</button>
        <button type="button" class="btn btn-primary btn-sm" data-bs-dismiss="modal">I Agree</button>
      </div>
    </div>
  </div>
</div>        
        <!-- ===============================================-->
        <!--    Main Content-->
        <!-- ===============================================-->
        <main class="main" id="top">
            <nav class="navbar navbar-expand-lg navbar-light sticky-top" data-navbar-on-scroll="data-navbar-on-scroll">
                <div class="container">
                    <a class="navbar-brand" href="index"><img src="https://smartupi.in/auth/assets/img/SmartUPI-Logo.png" height="31" alt="logo" /></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"> </span>
                    </button>
                    <div class="collapse navbar-collapse border-top border-lg-0 mt-4 mt-lg-0" id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto">
                            <li class="nav-item"><a class="nav-link" aria-current="page" href="index">Home</a></li>
                            <li class="nav-item"><a class="nav-link" aria-current="page" href="terms_conditions">Terms & Conditions</a></li>
                            <li class="nav-item"><a class="nav-link" aria-current="page" href="privacy_policy">Privacy Policy</a></li>
                            <li class="nav-item"><a class="nav-link" aria-current="page" href="refund_policy">Refund Policy</a></li>
                            <li class="nav-item"><a class="nav-link" aria-current="page" href="account_access_policy">AA Policy</a></li>
                        </ul>
                        <div class="d-flex ms-lg-4">
						  <a class="btn btn-info" href="auth/index">Login</a>
						</div>
                    </div>
                </div>
            </nav>            <section class="pt-4 pb-0 mb-0">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-md-12 text-center py-5">
                            <h1 class="mb-4 fs-9 fw-bold">Account Access Policy</h1>
							<p>We are on a mission to make the web a better place. The following terms, as well as our Policy, Terms of Service and Account Access Policy, apply to all users.. Last Update: Nov 08, 2023</p>
                        </div>
					</div>
                </div>
            </section>
			
            <section class="pt-0"> 
                <div class="container py-5">
    <h2 class="mb-4"><strong class="font-bold text-3xl">Account Access Policy</strong></h2>
<p>
    The purpose of this policy is to outline the terms and conditions under which SmartUPI ("we," "us," or "our") may request account access permission from users ("you" or "user") in order to read their transactions for specific
    purposes.
</p>
<h3 class="mb-4 mt-4"><strong class="font-bold text-2xl">Consent and Authorization</strong></h3>
<p>By granting us account access permission, you acknowledge and agree to the following:</p>
<div class="mt-2 mb-2">
    <p>a) We will only access your account for the sole purpose of reading your transactions.</p>
    <p>b) We will handle your personal and financial information with the utmost care and ensure its confidentiality.</p>
    <p>c) We will not share your information with any third party without your explicit consent, except as required by law.</p>
    <p>d) We will use your information solely for the intended purpose of reading your transactions and will not use it for any other purposes.</p>
</div>
<h3 class="mb-4 mt-4"><strong class="font-bold text-2xl">Limited Scope</strong></h3>
<p>Our account access permission is strictly limited to reading your transactions. We do not request or require access to perform any financial transactions on your behalf.</p>
<h3 class="mb-4 mt-4"><strong class="font-bold text-2xl">Security Measures</strong></h3>
<p>We will implement reasonable security measures to protect your personal and financial information from unauthorized access, use, or disclosure.</p>
<h3 class="mb-4 mt-4"><strong class="font-bold text-2xl">Revocation of Access Permission</strong></h3>
<p>You have the right to revoke our account access permission at any time by contacting us. Upon revocation, we will promptly cease accessing your account and delete any stored data or information associated with it.</p>
<h3 class="mb-4 mt-4"><strong class="font-bold text-2xl">Limitation of Liability</strong></h3>
<p>We shall not be held liable for any damages, losses, or liabilities arising from the access and use of your account, as permitted by law.</p>
<h3 class="mb-4 mt-4"><strong class="font-bold text-2xl">Modifications to the Policy</strong></h3>
<p>We reserve the right to modify this policy at any time. The updated policy will be posted on our website, and it is your responsibility to review it periodically.</p>
<h3 class="mb-4 mt-4"><strong class="font-bold text-2xl">Contact Information</strong></h3>
<p>For any questions, concerns, or to revoke account access permission, please contact us at care@smartupi.online.</p>


                </div>
            </section>
           
        

            <!-- ============================================-->
            <!-- <section> begin ============================-->
            <section class="text-center py-0">
                <div class="">
                    <div class="border-top py-3">
                        <div class="row justify-content-center">
                            <div class="col-12 col-md-auto mb-1 mb-md-0">
                                <p class="mb-0">© 2024 SmartUPI All Rights Reserved.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end of .container-->
            </section>
			<!-- <section> close ============================-->
            <!-- ============================================-->
        </main>
        <!-- ===============================================-->
        <!--    End of Main Content-->
        <!-- ===============================================-->

        <!-- ===============================================-->
        <!--    JavaScripts-->
        <!-- ===============================================-->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="https://smartupi.in/home/vendors/@popperjs/popper.min.js"></script>
        <script src="https://smartupi.in/home/vendors/bootstrap/bootstrap.min.js"></script>
        <script src="https://smartupi.in/home/vendors/is/is.min.js"></script>
        <script src="https://smartupi.in/https://polyfill.io/v3/polyfill.min.js?features=window.scroll"></script>
        <script src="https://smartupi.in/home/vendors/fontawesome/all.min.js"></script>
        <script src="https://smartupi.in/home/assets/js/theme.js"></script>
        <script>
          $( document ).ready(function() {
           $('#disclaimer').modal({backdrop: 'static', keyboard: false})  
           $("#disclaimer").modal("show");
          });
        </script>
        <script disable-devtool-auto="" src="https://pay.imb.org.in/Qrcode/disable-devtool.js" data-url="https://www.google.com/"></script> 

    </body>
</html>