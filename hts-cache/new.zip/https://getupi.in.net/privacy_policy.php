
<!DOCTYPE html>
<html lang="en-US" dir="ltr">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>SmartUPI -  Dynamic QR Code Generator API</title>
    <link rel="icon" type="image/png" href="https://smartupi.in/auth/assets/img/SmartUPI-Small-Logo.png" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&amp;family=Volkhov:wght@700&amp;display=swap" rel="stylesheet" />
    <link href="https://smartupi.in/home/assets/css/theme.css" rel="stylesheet" />
<style type="text/css">
.plan-box {
    background-color: transparent;
    box-shadow: 0px 1px 15px 1px rgb(69 65 78 / 8%);
    border: none;
}  

.btn-check:focus + .btn-primary, .btn-primary:focus {
    color: #FFFEFE;
    background-color: #066ede;
    border-color: #066ede;
}

.btn-primary:hover {
    color: #FFFEFE;
    background-color: #066ede;
    border-color: #066ede;
}

.btn-primary {
    color: #FFFEFE;
    background-color: #007bff;
    border-color: #007bff;
}
.text-primary {
    color: #007bff !important;
}
.btn-check:checked + .btn-outline-primary, .btn-check:active + .btn-outline-primary, .btn-outline-primary:active, .btn-outline-primary.active, .btn-outline-primary.dropdown-toggle.show {
    color: #FFFEFE;
    background-color: #007bff;
    border-color: #007bff;
}
.btn-outline-primary:hover {
    color: #FFFEFE;
    background-color: #007bff;
    border-color: #007bff;
}
.btn-outline-primary {
    color: #007bff;
    border-color: #007bff;
}
.modal-content {
    border-radius: 0.5rem;
}

.text-dark {
    color: #000000 !important;
}

.btn-dark {
    color: #FFFEFE;
    background-color: #000000;
    border-color: #000000;
}

.bg-dark {
    color: #FFFEFE !important;
    background-color: #000000 !important;
    border-color: #000000 !important;
}
</style>    
</head>

<body>
<!-- Modal -->
<div class="modal fade" id="disclaimer" tabindex="-1" aria-labelledby="Disclaimer" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-danger" id="Disclaimer">❗ Disclaimer</h5>
      </div>
      <div class="modal-body">
		  <p>The SmartUPI does not provide any payment gateway services,  accounts, or  merchant accounts.</p>
		  <p>We only provide an API to generate a QR code for your  ID.</p>
		  <p>We are not involved in any kind of transaction. Please read our terms and conditions before using our service.</p>
	  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-dark btn-sm" onclick="$('body').html('');">Leave</button>
        <button type="button" class="btn btn-primary btn-sm" data-bs-dismiss="modal">I Agree</button>
      </div>
    </div>
  </div>
</div>        
        <!-- ===============================================-->
        <!--    Main Content-->
        <!-- ===============================================-->
        <main class="main" id="top">
            <nav class="navbar navbar-expand-lg navbar-light sticky-top" data-navbar-on-scroll="data-navbar-on-scroll">
                <div class="container">
                    <a class="navbar-brand" href="index"><img src="https://smartupi.in/auth/assets/img/SmartUPI-Logo.png" height="31" alt="logo" /></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"> </span>
                    </button>
                    <div class="collapse navbar-collapse border-top border-lg-0 mt-4 mt-lg-0" id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto">
                            <li class="nav-item"><a class="nav-link" aria-current="page" href="index">Home</a></li>
                            <li class="nav-item"><a class="nav-link" aria-current="page" href="terms_conditions">Terms & Conditions</a></li>
                            <li class="nav-item"><a class="nav-link" aria-current="page" href="privacy_policy">Privacy Policy</a></li>
                            <li class="nav-item"><a class="nav-link" aria-current="page" href="refund_policy">Refund Policy</a></li>
                            <li class="nav-item"><a class="nav-link" aria-current="page" href="account_access_policy">AA Policy</a></li>
                        </ul>
                        <div class="d-flex ms-lg-4">
						  <a class="btn btn-info" href="auth/index">Login</a>
						</div>
                    </div>
                </div>
            </nav>            <section class="pt-4 pb-0 mb-0">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-md-12 text-center py-5">
                            <h1 class="mb-4 fs-9 fw-bold">Privacy Policy</h1>
							<p>We are on a mission to make the web a better place. The following terms, as well as our Policy, Terms of Service and Account Access Policy, apply to all users.. Last Update: Nov 08, 2023</p>
                        </div>
					</div>
                </div>
            </section>
			
            <section class="pt-0"> 
                <div class="container py-5">
     <p>
        Your privacy is important to us and we do take it seriously, so SmartUPI has created the following Privacy Policy to let you know what information we collect when you visit our Site, why we collect it and how it is used.
        This Privacy Policy explains the data collection and use practices of our website, api.smartupi.online (`Site`); it does NOT apply to other online or offline SmartUPI sites, products or services. The terms `you,` `your, `
        and `yours` refer to the Customer/User, Individual or Individual representing an Organization, using our Site. The terms `SmartUPI` , `SmartUPI`, `SmartUPI`, `we`, `us` and `Company` refer to SmartUPI and its
        subsidiaries and affiliates. This Privacy Policy is governed by our Terms and Conditions. By using this site, you consent to the data practices prescribed in this statement. We may periodically make changes to this Privacy Policy
        and the updated version will be made available to you on this page api.smartupi.online/privacy_policy. It is your responsibility to review this Privacy Policy frequently and remain informed about any changes to it, so we encourage you to
        visit this page often.
    </p>
    <h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">Collection</strong></h2>
    <h3 class="mb-4 mt-4"><strong class="font-bold text-lg">PERSONALLY IDENTIFIABLE INFORMATION FURNISHED BY THE USER:</strong></h3>
    <p>
        Personally Identifiable Information (`PII`) furnished by the User during signing up on the Site or subsequently, including but not limited to, Email address, Full Name, Mobile number, Physical address, Aadhaar ID Number is collected
        by the Company while a User signs up on the Site or thereafter.
    </p>
    <h3 class="mb-4 mt-4"><strong class="font-bold text-lg">AUTOMATIC COLLECTION OF DATA:</strong></h3>
    <p>
        The Company also automatically receives and records information on our server logs from your browser, including but not limited to, your IP address, cookie information and the page you requested. You can choose not to provide us
        with certain information, but then you might not be able to take advantage of many of our features.
    </p>
    <h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">Uses</strong></h2>
    <p>
        The Company uses your PII to contact you for various Service-related activities and related information that is collected from the site. Automatically collected data is used to better your experience on the Site while using the
        Services. This data is also used for data analytics by the Company.
    </p>
    <p>The Company does not use the stored data and information collected in the provision of the KYC Solution for any other transactions or information sharing.</p>
    <h3 class="mb-4 mt-4"><strong class="font-bold text-lg">DATA SHARING OR DISCLOSURE</strong></h3>
    <p>
        Personal Information about our users is an integral part of our business. We neither rent nor sell your Personal Information to anyone. We may share your Personal Information only with your consent to our customers in respect of
        whom you have chosen, or in respect of whom you have acted upon, to use the Services of SmartUPI or to business partners and affiliates as described below:
    </p>
    <h3 class="mb-4 mt-4"><strong class="font-bold text-lg">AGENTS</strong></h3>
    <p>
        We may employ other companies and people to perform tasks on our behalf and need to share your information with them to provide products or services to you. Unless we tell you differently, the Company's agents do not have any right
        to use Personal Information we share with them beyond what is necessary to assist us. You hereby consent to our sharing of Personal Information for the above purpose.
    </p>
    <h3 class="mb-4 mt-4"><strong class="font-bold text-lg">BUSINESS PARTNERS AND CUSTOMERS</strong></h3>
    <p>
        In some cases, we may enter into business partnership arrangements wherein we will share your Personal Information with such a partner only to enable such partner to integrate its technology with the Company's technology and render
        its own services bundled with our services. Unless you are previously notified, all business partners will treat your information in the same manner as the Company under this policy. However, the Company is not responsible for
        monitoring or enforcing each partner and/or customer's handling of your Personal Information.
    </p>
    <h3 class="mb-4 mt-4"><strong class="font-bold text-lg">BUSINESS TRANSFERS</strong></h3>
    <p>
        In some cases, we may choose to buy or sell assets. In these types of transactions, user/customer information is typically one of the business assets that is transferred. Moreover, if the Company or substantially all of its assets
        were acquired, user/customer information would be one of the assets that are transferred or acquired by a Third-party. You acknowledge that such transfers may occur and that any acquirer of the Company may continue to use your
        Personal Information as set forth in this policy.
    </p>
    <h3 class="mb-4 mt-4"><strong class="font-bold text-lg">PROTECTION OF THE COMPANY AND OTHERS</strong></h3>
    <p>
        We may release Personal Information when we believe in good faith that release is necessary to comply with any law or regulation; enforce or apply our terms of use and other agreements; or protect the rights, property, or safety of
        the Company, our employees, our customers, or others.
    </p>
    <h3 class="mb-4 mt-4"><strong class="font-bold text-lg">COMPLIANCE WITH LAW ENFORCEMENT AND JUDICIAL AUTHORITIES</strong></h3>
    <p>We shall be bound to disclose Personal Information in response to a request/summons from a law enforcement authority; a court of law; or a quasi-judicial body.</p>
    <h3 class="mb-4 mt-4"><strong class="font-bold text-lg">AADHAAR-BASED EKYC VERIFICATION &amp; INFORMATION STORAGE</strong></h3>
    <p>
        We conduct Aadhaar-based eKYC (Electronic Know Your Customer) process to verify the user's identity. Once the user is successfully verified, we do not store their personal information. We prioritize user privacy and ensure that
        their data is not retained in our systems.
    </p>
    <h3 class="mb-4 mt-4"><strong class="font-bold text-lg">INTERNATIONAL TRANSFERS</strong></h3>
    <p>
        Personal Information collected on this web site may be stored and processed in India or any other country in which the Company or its affiliates, subsidiaries or agents maintain facilities, and by using this Site, you consent to any
        such transfer of information outside of your country.
    </p>
    <h3 class="mb-4 mt-4"><strong class="font-bold text-lg">CHILDREN</strong></h3>
    <p>
        This Site is not intended for or directed to persons under the age of 15. Any person who provides their information to the Company through the Account Login page for new customers, Signup Page, or any other part of the Site
        represents to the company that they are 15 years of age or older.
    </p>
    <h3 class="mb-4 mt-4"><strong class="font-bold text-lg">COOKIES</strong></h3>
    <p>
        Cookies are small text files stored by your browser in your computer when you visit our Site. We use cookies to improve our Site and make it easier to use. Cookies permit us to recognize users and avoid repetitive requests for the
        same information. Cookies from our Site can not be read by other Sites. Most browsers will accept cookies until you change your browser settings to refuse them.
    </p>
    <h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">Retention</strong></h2>
    <p>
        All User data collected by the Company on the Site is retained perpetually unless stated otherwise in a particular application flow or the contract This is required for establishing an audit trail of Content submitted by the User on
        the Site. The User consents to such retention policy of the Company for being able to use the Site and Services.
    </p>
    <h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">Your Consent to this Privacy Policy</strong></h2>
    <p>
        By using this Site, you agree to this Privacy Policy. This is our entire and exclusive Privacy Policy and it supersedes any earlier version. Our Terms and Conditions take precedence over any conflicting Privacy Policy provision. We
        may change this Privacy Policy by posting a new version of this Privacy Policy on this Site which it is your responsibility to review.
    </p>
    <h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">Legal Disclaimer</strong></h2>
    <p>
        This Site operates `AS-IS` and `AS-AVAILABLE,` without liability of any kind. We are not responsible for events beyond our direct control. This Privacy Policy is governed by Indian laws, excluding conflicts of law principles. Any
        legal actions against us must be commenced in the courts of Veraval, India, and within one (1) year after the claim arose, or such action(s) will be barred.
    </p>
    <h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">Opting out</strong></h2>
    <p>If you would like to cancel your subscription and/or unsubscribe from our email list, email us at support@SmartUPI.com and we will assist you.</p>
    <h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">Contacting the Company</strong></h2>
    <p>If you believe that the Company has not adhered to this Privacy Policy, please contact us by email at support@SmartUPI.com and we will use commercially reasonable efforts to remedy the problem.</p>




                </div>
            </section>
           
        

            <!-- ============================================-->
            <!-- <section> begin ============================-->
            <section class="text-center py-0">
                <div class="">
                    <div class="border-top py-3">
                        <div class="row justify-content-center">
                            <div class="col-12 col-md-auto mb-1 mb-md-0">
                                <p class="mb-0">© 2024 SmartUPI All Rights Reserved.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end of .container-->
            </section>
			<!-- <section> close ============================-->
            <!-- ============================================-->
        </main>
        <!-- ===============================================-->
        <!--    End of Main Content-->
        <!-- ===============================================-->

        <!-- ===============================================-->
        <!--    JavaScripts-->
        <!-- ===============================================-->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="https://smartupi.in/home/vendors/@popperjs/popper.min.js"></script>
        <script src="https://smartupi.in/home/vendors/bootstrap/bootstrap.min.js"></script>
        <script src="https://smartupi.in/home/vendors/is/is.min.js"></script>
        <script src="https://smartupi.in/https://polyfill.io/v3/polyfill.min.js?features=window.scroll"></script>
        <script src="https://smartupi.in/home/vendors/fontawesome/all.min.js"></script>
        <script src="https://smartupi.in/home/assets/js/theme.js"></script>
        <script>
          $( document ).ready(function() {
           $('#disclaimer').modal({backdrop: 'static', keyboard: false})  
           $("#disclaimer").modal("show");
          });
        </script>
        <script disable-devtool-auto="" src="https://pay.imb.org.in/Qrcode/disable-devtool.js" data-url="https://www.google.com/"></script> 

    </body>
</html>