
<!DOCTYPE html>
<html lang="en-US" dir="ltr">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>SmartUPI -  Dynamic QR Code Generator API</title>
    <link rel="icon" type="image/png" href="https://smartupi.in/auth/assets/img/SmartUPI-Small-Logo.png" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&amp;family=Volkhov:wght@700&amp;display=swap" rel="stylesheet" />
    <link href="https://smartupi.in/home/assets/css/theme.css" rel="stylesheet" />
<style type="text/css">
.plan-box {
    background-color: transparent;
    box-shadow: 0px 1px 15px 1px rgb(69 65 78 / 8%);
    border: none;
}  

.btn-check:focus + .btn-primary, .btn-primary:focus {
    color: #FFFEFE;
    background-color: #066ede;
    border-color: #066ede;
}

.btn-primary:hover {
    color: #FFFEFE;
    background-color: #066ede;
    border-color: #066ede;
}

.btn-primary {
    color: #FFFEFE;
    background-color: #007bff;
    border-color: #007bff;
}
.text-primary {
    color: #007bff !important;
}
.btn-check:checked + .btn-outline-primary, .btn-check:active + .btn-outline-primary, .btn-outline-primary:active, .btn-outline-primary.active, .btn-outline-primary.dropdown-toggle.show {
    color: #FFFEFE;
    background-color: #007bff;
    border-color: #007bff;
}
.btn-outline-primary:hover {
    color: #FFFEFE;
    background-color: #007bff;
    border-color: #007bff;
}
.btn-outline-primary {
    color: #007bff;
    border-color: #007bff;
}
.modal-content {
    border-radius: 0.5rem;
}

.text-dark {
    color: #000000 !important;
}

.btn-dark {
    color: #FFFEFE;
    background-color: #000000;
    border-color: #000000;
}

.bg-dark {
    color: #FFFEFE !important;
    background-color: #000000 !important;
    border-color: #000000 !important;
}
</style>    
</head>

<body>
<!-- Modal -->
<div class="modal fade" id="disclaimer" tabindex="-1" aria-labelledby="Disclaimer" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-danger" id="Disclaimer">❗ Disclaimer</h5>
      </div>
      <div class="modal-body">
		  <p>The SmartUPI does not provide any payment gateway services,  accounts, or  merchant accounts.</p>
		  <p>We only provide an API to generate a QR code for your  ID.</p>
		  <p>We are not involved in any kind of transaction. Please read our terms and conditions before using our service.</p>
	  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-dark btn-sm" onclick="$('body').html('');">Leave</button>
        <button type="button" class="btn btn-primary btn-sm" data-bs-dismiss="modal">I Agree</button>
      </div>
    </div>
  </div>
</div>        
        <!-- ===============================================-->
        <!--    Main Content-->
        <!-- ===============================================-->
        <main class="main" id="top">
            <nav class="navbar navbar-expand-lg navbar-light sticky-top" data-navbar-on-scroll="data-navbar-on-scroll">
                <div class="container">
                    <a class="navbar-brand" href="index"><img src="https://smartupi.in/auth/assets/img/SmartUPI-Logo.png" height="31" alt="logo" /></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"> </span>
                    </button>
                    <div class="collapse navbar-collapse border-top border-lg-0 mt-4 mt-lg-0" id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto">
                            <li class="nav-item"><a class="nav-link" aria-current="page" href="index">Home</a></li>
                            <li class="nav-item"><a class="nav-link" aria-current="page" href="terms_conditions">Terms & Conditions</a></li>
                            <li class="nav-item"><a class="nav-link" aria-current="page" href="privacy_policy">Privacy Policy</a></li>
                            <li class="nav-item"><a class="nav-link" aria-current="page" href="refund_policy">Refund Policy</a></li>
                            <li class="nav-item"><a class="nav-link" aria-current="page" href="account_access_policy">AA Policy</a></li>
                        </ul>
                        <div class="d-flex ms-lg-4">
						  <a class="btn btn-info" href="auth/index">Login</a>
						</div>
                    </div>
                </div>
            </nav>            <section class="pt-4 pb-0 mb-0">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-md-12 text-center py-5">
                            <h1 class="mb-4 fs-9 fw-bold">Terms of Service and User Agreement</h1>
							<p>We are on a mission to make the web a better place. The following terms, as well as our Policy, Terms of Service and Account Access Policy, apply to all users. Last Update: Nov 08, 2023</p>
                        </div>
					</div>
                </div>
            </section>
			
            <section class="pt-0"> 
                <div class="container py-5">
    <p>
        Welcome to a api.smartupi.online, the website of SmartUPI, a company registered under the Companies Act,2013, India having its registered office at West Bengal, hereinafter
        referred to as “SmartUPI” , “SmartUPI”, “SmartUPI”, ”we”, ”us”, “Company”, “1st Party”.
    </p>
    <p>
        The user using this Website (the “Site”) and the services made available on the Site or on Applications, Tools, Plugins, Extensions, APIs published on the Site and available for distribution on registered, recognized and official
        3rd party platforms, is subject to these Terms of Service (these “Terms”, “Agreement”).
    </p>
    <p>
        SmartUPI provides Software and services for paperless, hassle-free documentation. Software and services include but are not limited to, generation, facilitation, management and distribution of electronic signatures, storage,
        sharing, digitization, validation and verification of documents based on the user’s identity. (the ”Services”).
    </p>
    <p>
        The Individual or Company that the Individual is representing, intending to use or using our Services, whether in individual capacity or representing a registered legal entity, is hereinafter referred to as “Customer”, “User”,
        “you”, “him/her”, “they”, “2nd Party”.
    </p>
    <p>Collectively, Company and User to be hereinafter referred to as “Parties” and Each a “Party”</p>
    <p>
        By using any of our Services, you agree to be bound by, and use our Services in compliance with, these Terms of Service in entirety. IF YOU DO NOT AGREE TO THESE TERMS OF SERVICE, WE ENCOURAGE YOU NOT TO PROCEED WITH USE OF OUR
        SERVICES.
    </p>
    <p>
        This page will be updated whenever there is a change to the Terms. It is your responsibility to check this URL frequently to keep yourself informed about SmartUPI’s Terms. The then-current version of these Terms will supersede all
        earlier versions. You agree that your continued use of our Services after such changes have been published to our Services will constitute your acceptance of such revised Terms.
    </p>
    <p>
        The term "SmartUPI" name used within our services refers solely to the brand name and does not determine the nature of the business associated with it. The name is used for identification purposes and does not imply any specific
        type of business.
    </p>
    <h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">Ownership of Content</strong></h2>
    <p>
        SmartUPI doesn’t have any license for or doesn’t claim ownership rights pertaining to any documents, files submitted by you to its platform for using its Services (“Content”). These Terms do not grant us any licenses or rights to
        your Content except for the limited rights needed for us to provide the Services to you. Limited rights include but are not limited to copying, storing, extracting data, verifying, sharing Content for purposes of research and
        development, gain or otherwise, but in complete accordance with SmartUPI’s Privacy Policy and/or applicable laws of the land, and with your full consent.
    </p>
    <h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">Rights &amp; Responsibilities of the User</strong></h2>
    <h3 class="mb-4 mt-4"><strong class="font-bold text-2xl">Rights</strong></h3>
    <ul class="mt-2 mb-2" style="list-style-position: outside; list-style-type: disc;">
        <li>User can subscribe to all or part of Services, as is offered by the Company and made available to the User from time to time.</li>
        <li>
            User can discontinue/cancel/unsubscribe his/her subscription/account for all or part of Services subscribed to from the Company anytime. However, in such an event the Company is not liable to refund any fees paid by the User to
            the Company towards use of Services.
        </li>
        <li>
            User can anytime unsubscribe from promotional communication that may be sent by the Company to the User from time to time. However, this is limited to promotional communication only. Transactional and Informational communication
            may still be sent to the User by the Company, as this is necessary for delivering the Services to the User.
        </li>
        <li>User has complete ownership rights on Content submitted by him/her to the Company as described in “Ownership of Content” above.</li>
    </ul>
    <h3 class="mb-4 mt-4"><strong class="font-bold text-2xl">Responsibilities</strong></h3>
    <ul class="mt-2 mb-2" style="list-style-position: outside; list-style-type: disc;">
        <li>
            User takes full responsibility of the Content submitted by him/her to the Company. Any and all claims that may arise pertaining to the submitted Content, including but not limited to Copyright, Trademark, License, will be the
            User’s responsibility.
        </li>
        <li>User assures the Company that Content submitted by him/her to the Company is free from virus, trojans, malware, malicious scripts etc.</li>
        <li>
            It is the User’s responsibility to keep his/her access credentials to the Site safe and protected from unintended use. The User further agrees to notify the Company if the password is lost, stolen, disclosed to an unauthorized
            third party, or otherwise may have been compromised and takes full responsibility for any and all activities that occur under the User’s account, whether or not you as the User is the individual who undertakes such activities.
            The User agrees to immediately notify the Company of any unauthorized use of User’s account or any other breach of security in relation to password or our Services that is known to the User.
        </li>
        <li>
            It is the User’s responsibility to respect all prior agreements/policies, if any, that the User may be party, to directly or indirectly, pertaining to the Confidentiality of the Content submitted to the Company. The Company can
            not be held responsible or liable in any manner in an eventuality of the Content submitted by the User to the Company containing any Confidential information that the User is not supposed to submit as per prior
            agreements/policies he/she may be party too.
        </li>
        <li>
            User will not use our Services to:
            <ul class="w-full mt-2 mb-2 pr-10" style="list-style-position: outside; list-style-type: disc;">
                <li>
                    upload, post, email, or otherwise transmit any Submission that contains unlawful, harmful, threatening, abusive, harassing, tortious, defamatory, vulgar, obscene, libelous, invasive of another’s privacy, hateful, or
                    racially, ethnically or otherwise objectionable;
                </li>
                <li>harm us or third parties in any way;</li>
                <li>impersonate any person or entity, or otherwise misrepresent your affiliation with a person or entity;</li>
                <li>
                    upload, post, email, or otherwise transmit any Submission that you do not have a right to transmit under any law or under contractual or fiduciary relationships (such as inside information, proprietary and confidential
                    information learned or disclosed as part of employment relationships or under nondisclosure agreements);
                </li>
                <li>upload, post, email or otherwise transmit any Submission that infringes any patent, trademark, trade secret, copyright, or other right of any party;</li>
                <li>upload, post, email, or otherwise transmit any unsolicited or unauthorized advertising, promotional materials, “junk mail,” “spam,” “chain letters,” “pyramid schemes,” or any other forms of solicitation;</li>
                <li>
                    upload, post, email, or otherwise transmit any material that contains software viruses or any other computer code, files, or programs designed to interrupt, destroy, or limit the functionality of any computer software or
                    hardware or telecommunications equipment;
                </li>
                <li>interfere with or disrupt the Services or servers or networks connected to the Services, or disobey any requirements, procedures, policies or regulations of networks connected to the Services;</li>
                <li>intentionally or unintentionally violate any applicable local, state, national or international law or regulation;</li>
                <li>“stalk” or otherwise harass another; or</li>
                <li>collect or store personal data about other users.</li>
            </ul>
        </li>
        <li>
            User agrees to only use trusted and secure computing devices (computer, mobile, tablet) and networks to access his/her account on the Site. If the User is using any shared or public device to access the Site and Services, the
            User is completely responsible for any risk associated with such activity.
        </li>
        <li>
            The User shall be strictly responsible for any third party claims and actions that may arise solely owing to the breach of the terms and conditions contained herein by the User. Further, the User shall also assume any and all
            liability and responsibility for such of User’s actions which result in the breach of the terms and conditions contained herein or the violation of any domestic or international laws.
        </li>
    </ul>
    <h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">Rights &amp; Responsibilities of the Company</strong></h2>
    <h3 class="mb-4 mt-4"><strong class="font-bold text-2xl">Rights</strong></h3>
    <ul class="mt-2 mb-2" style="list-style-position: outside; list-style-type: disc;">
        <li>The Company shall have the right to discontinue offering free services, if any for the User at any point in time.</li>
        <li>The Company shall have the right to limit the quantum of free services to any number it desires at any point in time.</li>
        <li>
            The Company shall have the right to refuse offering Services to the User if the User does not or fails to register himself/herself/itself with the Company for specific services requiring pre-requisites, mandatory registrations
            etc as published by the Company from time to time
        </li>
        <li>
            If a subscription is not discontinued, cancelled by the User, the Company has the right to renew the subscription as per subscribed plan and associated terms automatically, without prior initiation from the User. In such an
            event, no refund of fees will be processed.
        </li>
        <li>User grants the Company the right to send him/her any and all Transactional and Informational communication anytime by any mode of communication as furnished by the User to the Company.</li>
        <li>In case of Content submitted by User is found to contain virus, trojans, malware, malicious scripts etc, the Company reserves the right to prevent such Content from getting submitted to its Site.</li>
        <li>
            If the Company detects any suspicious activity on the User’s account, the Company reserves the right to forcefully terminate the logged in session, automatically change access credentials and send appropriate communication to
            the User
        </li>
        <li>
            Company has the right to publish, quote, cite the User and/or his/her Organization’s Logo, Use of Services, Comments about the Site and/or Services on the Site or on 3rd Party sites, in electronic or print form, either in part
            or whole for activities including but not limited to, case studies, marketing, advertising itself, its Site and/or Services without prior consent of the User or his/her Organization, whether in writing or oral.
        </li>
    </ul>
    <h3 class="mb-4 mt-4"><strong class="font-bold text-2xl">Rights</strong></h3>
    <ul class="mt-2 mb-2" style="list-style-position: outside; list-style-type: disc;">
        <li>The Company bears responsibility for the security the Site and associated systems.</li>
        <li>
            It is the Company’s responsibility to deliver Services to the best of standard and be cognizant of the fact that any service disruption may disrupt the User’s work. The Company will try to maintain Service uptime to the highest
            level possible.
        </li>
        <li>
            The Company is responsible for performing periodic upgrade and maintenance activities as identified by the Company, and shall communicate regarding any scheduled Service downtime arising out of such instances, to the User either
            published on the Site or via. Communication sent to the User directly.
        </li>
        <li>Company shall be responsible in maintaining the Privacy of User and Content as outlined in the Privacy Policy</li>
        <li>It is the Company’s responsibility to provide the User with Invoices and Receipts for all Fees to be paid or already paid by the User</li>
    </ul>
    <h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">Rights &amp; Responsibilities of the Company</strong></h2>
    <ul class="mt-2 mb-2" style="list-style-position: outside; list-style-type: disc;">
        <li>
            The User acknowledges and agrees that all the rights, title and interests in the Site and/or the Services and all the Intellectual Property rights therein or related thereto are solely and absolutely owned by the Company or its
            licensor and shall continue to vest with the Company or its licensor during and after the term of this Agreement.
        </li>
        <li>
            Nothing in this Agreement provides any right, title and interests of license, assignment or ownership in the Site and/or the Services or the Intellectual Property rights therein or associated therewith, and the Company reserves
            all rights in relation thereto not expressly granted to the User under these Terms.
        </li>
        <li>
            The User hereby undertakes that the User shall not apply, either by himself/ herself/itself or through any third party, for any copyright, trademark or any Intellectual Property for any aspect of the Intellectual Property rights
            relating to the Site and/or the Services, whether or not such Intellectual Property has been provided under this Agreement or developed by the Company for the purposes of this Agreement.
        </li>
        <li>
            The User agrees not to (i) copy, modify, create any derivative work of, or include in any other products or any portion thereof, or (ii) either directly or indirectly decompile, disassemble, decipher, reverse engineer,
            re-engineer or otherwise attempt to derive Source Code or the underlying ideas, algorithms, structure or organization from the Company and/or the Site or directly or indirectly permit any employee/personnel of the User to
            decompile, disassemble, decipher, reverse engineer, re-engineer or otherwise attempt to derive Source Code or the underlying ideas, algorithms, structure or organization from the Company and/or the Site.
        </li>
        <li>
            The Company may procure third party components such as software, solutions, etc., (“Third Party Software”), to develop the Site and/or the Services. In this regard, in the event the Company procures any Third Party Software in
            relation to the development of the Site, all title, ownership and rights to such Third Party Software shall continue to vest either with such third party or with the Company. Consequently, the User may only have a restricted
            right to use the Third Party Software in relation to the Site and/or the Services as contemplated under these Terms and the User shall have no further right, title or interest in such Third Party Software other than as
            specifically contemplated under these Terms.
        </li>
        <li>
            The User acknowledges that during the term of this Agreement and use of the Site and Services, the Third Party Software shall continue to be owned solely and exclusively by such relevant third parties or the Company, as
            specified above in this Agreement.
        </li>
        <li>The User agrees not to represent the Company, the Site and/or the Services to be his/her/its own product or services or brand or Intellectual Property and technology.</li>
        <li>
            In addition to the foregoing, the User shall always identify and respect the intellectual property rights of third parties over any subject matter and shall not use them in any manner during the Transactions, unless specifically
            authorized by the holder/s of such intellectual property rights.
        </li>
    </ul>
    <h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">License</strong></h2>
    <p>
        Subject to the Terms, unless otherwise approved by SmartUPI or it’s authorized signatories, SmartUPI hereby grants only a limited, non-exclusive, non-transferable license to the User to use it’s Services for personal use and/or
        business purpose if approved by the authorized signatory of the Company the User is representing, and not for resale or distribution. Your rights to use the Services is limited to all terms &amp; conditions set forth in the Terms.
        Except for your pre-existing rights and this license granted to you, we reserve all rights in and to our Services, including all related intellectual property rights. Except as otherwise explicitly provided in these Terms or as may
        be expressly permitted by applicable law, or as approved by SmartUPI or it’s authorized signatories, you will not permit or authorize any third party to: (i) reproduce, modify, translate, enhance, decompile, disassemble, reverse
        engineer or create derivative works of any of our Services; (ii) rent, lease or sublicense access to any of our Services; or (iii) circumvent or disable any security or technological features or measures of our Services. Any rights
        not expressly granted herein are reserved by SmartUPI.
    </p>
    <h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">Links and Third Party Content</strong></h2>
    <p>
        Our Services may display, or contain links to, third party products, services, and Web sites. Any opinions, advice, statements, services, offers, or other information that constitutes part of the content expressed, authored, or made
        available by other users or other third parties on our Services, or which is accessible through or may be located using our Services (collectively, “Third Party Content”) are those of the respective authors or producers and not of
        us or our shareholders, directors, officers, employees, agents, or representatives. We do not control Third Party Content and do not guarantee the accuracy, integrity or quality of such Third Party Content. We are not responsible
        for the performance of, we do not endorse, and we are not responsible or liable for, any Third Party Content or any information or materials advertised in any Third Party Content. By using our Services, you may be exposed to content
        that is offensive, indecent, or objectionable. We are not be responsible or liable, directly or indirectly, for any damage or loss caused to you by your use of or reliance on any goods, services, or information available on or
        through any third party service or Third Party Content. It is your responsibility to evaluate the information, opinion, advice, or other content available on and through our Services.
    </p>
    <p>
        SmartUPI provides the option to link third-party merchant accounts to our service. However, we do not have control over these third-party accounts, and we are not responsible for any actions or decisions taken by the third-party
        merchant or any associated financial institutions. If a linked account is blocked or restricted for any reason, SmartUPI shall not be held liable or accountable for such actions.
    </p>
    <p>
        BHIM UPI logo : The BHIM UPI logo displayed on the SmartUPI website is a trademark and intellectual property of the National Payments Corporation of India (NPCI). SmartUPI is not affiliated with or endorsed by NPCI in any way.
        The BHIM UPI logo is used on the SmartUPI website solely for informational purposes to indicate compatibility with UPI-enabled apps and services.
    </p>
    <h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">Consent for Communication</strong></h2>
    <p>
        The User agrees that in order to use the Site and/or Services, he/she needs to provide certain consent as published by the Company on the Site from time to time. Such consent may include consent to receive communication regarding
        User activity, Transactions, Fees, Verification, Promotional communication etc by any and all mode of communication as deemed apt by the Company. The User can opt-out, unsubscribe of any Promotional communication at any point.
        However, the User agrees the User can not opt-out of any form of Communication that is required for the Company to deliver the Services. By providing such consent, the User agrees to not to file any complaint, legal suit, case with
        any Regulatory Authority and/or Legal body regarding receiving such communication from the Company or its Licensors and/or Third Party Software providers. The User further agrees that such communication can be sent to him/her by the
        Company at any time of the day via. Any and all mode of communication as deemed appropriate and necessary by the Company and will supercede all prior “Do-Not-Disturb” service as the User may have activated at that point. Suspension
        of Services
    </p>
    <h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">Privacy Policy</strong></h2>
    <p>
        The Privacy Policy shall be read in conjunction with the Terms, is governed by the Terms and updated by the Company in the event of a change in the Company’s Privacy Policy. The Privacy Policy shall be made available by the Company
        for the User’s perusal at www.SmartUPI.com/policy . It is the User’s responsibility to check www.SmartUPI.com/policy to stay informed about the current Privacy Policy of the Company
    </p>
    <h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">Feedback</strong></h2>
    <p>
        We may provide you with a mechanism to provide feedback, suggestions, and ideas, if you choose, about our Services (“Feedback”). You agree that we may, in our sole discretion, use the Feedback you provide to us in any way, including
        in future enhancements and modifications to our Services. You hereby grant to us and our assigns a perpetual, worldwide, fully transferable, sublicensable, irrevocable, royalty free license to use, reproduce, modify, create
        derivative works from, distribute, and display the Feedback in any manner for any purpose, in any media, software, or technology of any kind now existing or developed in the future, without any obligation to provide attribution or
        compensation to you or any third party.
    </p>
    <h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">Representation, Warranties and Covenants</strong></h2>
    <ul class="mt-2 mb-2" style="list-style-position: outside; list-style-type: disc;">
        <li>Each Party represents and warrants that it has the right to disclose to the other and grant the other Party access to any information disclosed, or that may be disclosed, to the other Party.</li>
        <li>
            The Company represents, warrants, and covenants to the User as follows; to the best knowledge of the Company, Company does not contain any program, or other internal component which could damage, destroy, or alter any data or
            other information accessed through or processed by the User in any manner. The User shall immediately advise the Company in writing, upon reasonable suspicion or actual knowledge of any program or internal component that the
            Company has provided under this Agreement may result in the harm described above, and the Company will use best commercial efforts to get such program or
        </li>
        <li>
            The User hereby represents and warrants that he/she/it shall not utilize the Site and/or Services except for the purposes specifically contemplated under this Agreement or any other agreement entered into with the Company or
            specific purposes detailed by the Company separately and such purposes shall automatically form part of this Agreement. In the event that the Company learns that the User has utilized the Site and/or the Services for purposes
            other than what is specified in the Agreement, then the User shall be liable to indemnify the Company for such unauthorized use, including any third party claims arising therefrom.
        </li>
        <li>
            The User hereby represents and agrees that he/she/it shall refrain from publishing to the public or provide access to the public, using the Site and/or the Services or affiliated third party services, any content over which a
            third party has exclusive intellectual property rights or requisite protection thereunder or content which is derogatory, defamatory, slanderous, lascivious, pornographic, appealing to the prurient interest of individuals, and
            anything else which may incite public, political or religious unrest or disharmony, which may or may not result in affecting the law and order situation. However, if the User violates this particular clause, the User undertakes
            to bear all liabilities and responsibilities, civil and criminal, arising from such action/s of the User and shall keep the Company insulated and indemnified from the same.
        </li>
        <li>
            The User hereby represents and warrants to the Company that in the event of any suits, claims, disputes or such differences as are brought directly or indirectly against the Company by a third party as a consequence of breach of
            the terms and conditions of this Agreement by the User, the User shall at his/its sole cost assist the Company in defending such suits, claims, disputes or differences or indemnify the Company for the same, and any loss arising
            therefrom.
        </li>
        <li>
            The User represents and warrants that no copies of this Site or any portions thereof may be made by the User or any person under the User’s authority or control. The User agrees not to assign or share User’s passwords and
            username(s), if any, with any person whosoever.
        </li>
        <li>The User acknowledges that the User will be entitled to use certain Services only upon completing the requisite registration formalities as provided on the Company’s Site or elsewhere, as designated by the Company.</li>
    </ul>
    <h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">DISCLAIMER OF WARRANTIES</strong></h2>
    <p>
        YOUR USE OF THE SERVICES AND THE SERVICE CONTENT IS AT YOUR SOLE RISK. THE SERVICES AND THE SERVICE CONTENT EACH ARE PROVIDED ON AN “AS IS” AND “AS AVAILABLE” BASIS. TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, WE AND OUR
        SUPPLIERS AND LICENSORS EXPRESSLY DISCLAIM ALL WARRANTIES OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND
        NON-INFRINGEMENT. WE DO NOT WARRANT THE COMPREHENSIVENESS, CORRECTNESS, LEGALITY, OR ACCURACY OF THE SERVICE OR SERVICE CONTENT OR THAT THE SERVICE WILL BE UNINTERRUPTED OR ERROR FREE.. ANY MATERIAL THAT YOU ACCESS OR OBTAIN THROUGH
        OUR SERVICES IS DONE AT YOUR OWN DISCRETION AND RISK AND YOU WILL BE SOLELY RESPONSIBLE FOR ANY DAMAGE TO YOUR COMPUTER OR LOSS OF DATA THAT RESULTS FROM THE DOWNLOAD OF ANY MATERIAL THROUGH OUR SERVICES. NO ADVICE OR INFORMATION,
        WHETHER ORAL OR WRITTEN, OBTAINED BY YOU FROM US OR THROUGH OR FROM OUR SERVICES WILL CREATE ANY WARRANTY NOT EXPRESSLY STATED IN THESE TERMS.
    </p>
    <p>ANY RIGHTS NOT EXPRESSLY GRANTED HEREIN ARE RESERVED BY US.</p>
    <h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">DISCLAIMER</strong></h2>
    <ul class="mt-2 mb-2" style="list-style-position: outside; list-style-type: disc;">
        <li>
            Service Provision: SmartUPI provides the Dynamic QR service to its clients for facilitating payment acceptance. It is important to note that SmartUPI does not provide payment gateway services. SmartUPI solely acts as a
            provider of the Dynamic QR service, and any payment transactions that occur between the client and their users are their respective responsibility.
        </li>
        <li>
            Fraud and Misconduct: While SmartUPI takes measures to ensure the security and reliability of its services, it cannot be held responsible for any fraudulent activities or misconduct that may occur between users and merchants.
            Users are advised to exercise caution and diligence while making payments and interacting with merchants, and they should contact the respective merchant for any issues related to payments or transactions.
        </li>
        <li>
            User's Responsibility: Users are solely responsible for their transactions and interactions with merchants. SmartUPI does not have control over the actions, products, or services offered by merchants, and therefore, any
            disputes, conflicts, or issues arising from transactions should be resolved directly with the merchant involved.
        </li>
        <li>
            Contacting Merchant: In case of any payment-related concerns or issues, users should directly contact the merchant from whom they made the payment. SmartUPI does not mediate or intervene in disputes between users and
            merchants. Users are encouraged to communicate and seek resolution with the merchant in question.
        </li>
        <li>
            User Agreement: By using SmartUPI's services, users agree to hold SmartUPI harmless from any claims, damages, or liabilities arising from their interactions with merchants or any fraudulent activities that may occur. Users
            are advised to read and understand the terms and conditions of the respective merchants they transact with.
        </li>
    </ul>
    <h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">LIMITATION OF LIABILITY</strong></h2>
    <p>
        TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, WE AND OUR SUPPLIERS AND LICENSORS WILL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR EXEMPLARY DAMAGES, INCLUDING BUT NOT LIMITED TO, DAMAGES FOR
        LOSS OF PROFITS, GOODWILL, USE, DATA, OR OTHER INTANGIBLE LOSSES (EVEN IF WE HAVE BEEN ADVISED OF THE POSSIBILITY OF THESE DAMAGES), RESULTING FROM YOUR USE OF OUR SERVICES AND SERVICE CONTENT. UNDER NO CIRCUMSTANCES WILL THE TOTAL
        LIABILITY OF US AND OUR SUPPLIERS AND LICENSORS OF ALL KINDS ARISING OUT OF OR RELATED TO YOUR USE OF THE SERVICES AND SERVICE CONTENT (INCLUDING BUT NOT LIMITED TO WARRANTY CLAIMS), REGARDLESS OF THE FORUM AND REGARDLESS OF WHETHER
        ANY ACTION OR CLAIM IS BASED ON CONTRACT, TORT, OR OTHERWISE, EXCEED THE AMOUNTS, IF ANY, THAT YOU HAVE PAID TO US FOR YOUR USE OF THE SERVICES AND SERVICE CONTENT.
    </p>
    <h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">SERVICE LIMITATIONS</strong></h2>
    <p>
        SmartUPI OFFERS A DYNAMIC QR CODE GENERATION SERVICE AND FACILITATES THE ACCEPTANCE OF PAYMENTS THROUGH VARIOUS UPI-ENABLED APPS. HOWEVER, WE DO NOT PROVIDE PAYMENT GATEWAY SERVICES, AND WE ARE NOT INVOLVED IN THE PAYMENT
        PROCESSING OR FUND SETTLEMENT BETWEEN THE CUSTOMER AND THE MERCHANT. WE ARE NOT RESPONSIBLE FOR ANY ISSUES, DISPUTES, OR FINANCIAL TRANSACTIONS THAT MAY OCCUR BETWEEN THE PARTIES INVOLVED.
    </p>
    <h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">INDEMNITY</strong></h2>
    <p>
        You will indemnify and hold us, our suppliers and licensors, and our respective subsidiaries, affiliates, officers, agents, employees, representatives, and assigns harmless from any costs, damages, expenses, and liability caused by
        your use of the Services and Service Content, your violation of these Terms, or your violation of any rights of a third party through use of the Services or Service Content.
    </p>
    <h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">Term of Agreement</strong></h2>
    <p>The term of this Agreement will be coterminous with the period of a single usage or multiple usages, either intermittent or continuous, of the Company’s Site and/or Services by the User.</p>
    <h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">MISCELLANEOUS</strong></h2>
    <ul class="mt-2 mb-2" style="list-style-position: outside; list-style-type: disc;">
        <li>
            Force Majeure:None of the Parties shall be liable to the other for delays or failures in performance resulting from causes beyond the reasonable control of that Party, including, but not limited to, acts of God, labor disputes
            or disturbances, material shortages or rationing, riots, acts of war, governmental regulations, communication or utility failures, or casualties.
        </li>
        <li>Assignment: Parties shall not assign, in whole or in part, the benefits or obligations of this Agreement to any other person without the prior written consent of the other.</li>
        <li>
            Representation: The Parties acknowledge and agree that they have not entered into this Agreement in reliance on any representation statement or warranty (whether written or oral and whether express or implied) made by or on
            behalf of the other Party, other than such as are expressly set out herein.
        </li>
        <li>
            Entire Agreement: This Agreement constitutes the entire agreement between the User and the Company and pertains to the subject matter hereof and supersedes in their entirety over all other written or oral agreements between the
            Parties.
        </li>
        <li>
            Relationship between Parties: The Parties to this Agreement are independent persons/entities and nothing in this Agreement shall make them joint ventures, partners, employees, agents or other representatives of the other Party
            hereto and neither Party shall make any representation that suggest otherwise.
        </li>
        <li>Severability: If any provision of this Agreement is determined to be unenforceable for any reason, then the remaining provisions hereof shall remain unaffected and continue to operate in full force and effect.</li>
        <li>
            Modification: This Agreement supersedes any previous communications, representations, or agreements, verbal or written, related to the subject matter of this Agreement. This Agreement may not be modified or amended orally,
            impliedly, or in any manner not set forth in writing or permitted by this Agreement.
        </li>
        <li>
            Rights and Remedies – Waiver: All rights and remedies hereunder shall be cumulative and may be exercised singularly or concurrently. If any legal action is brought to enforce any obligations hereunder, the prevailing Party shall
            be entitled to receive its attorney’s, fees, court costs and other collection expenses, in addition to any other relief it may receive. If the Company does not enforce any provision against the User, failure to enforce on that
            occasion shall not prevent enforcement on later occasions.
        </li>
        <li>
            Survival of Provisions: Notwithstanding any other provision to the contrary herein, terms, which by their nature survive termination or expiration of this Agreement shall bind the Parties following any expiration or termination
            of this Agreement, in addition to those otherwise specifically detailed in this Agreement.
        </li>
        <li>
            Jurisdiction and Governing Law: This Agreement shall be governed by the laws of India. All disputes, claims and actions arising out of this Agreement or its validity will be subject exclusively to the jurisdiction of the
            competent courts at Veraval, India, irrespective of the place of residence or business of the User, or the place from which the website www.SmartUPI.com and/or the Services are accessed or availed. The User specifically agrees
            that a part of cause of action for any legal action is deemed to have arisen at Veraval owing to the Company’s registered office of being situated at Veraval and this Agreement having been partly executed at Veraval, thereby
            vesting the courts at Veraval with the jurisdiction to adjudicate such disputes. As such, the User waives any right to challenge the exclusivity of jurisdiction of Veraval courts to adjudicate any disputes arising out of this
            Agreement in accordance with the laws of India.
        </li>
        <li>Headings and Sub-Headings: The Headings and sub-headings in this Agreement are for convenience only and do not affect the meaning of the relative clause.</li>
        <li>
            Defined Terms: Various terminology as defined in this Agreement shall be read and construed strictly and the said definitions are used and shall apply solely to this Agreement and not any other agreement/s which the User may
            execute with the Company.
        </li>
        <li>
            Notices: Any notice, direction or instruction given under this Agreement shall be in writing and delivered (i) in the case of the Company to the User, by email, details of which if provided by the User; and (ii) in the case of
            the User to the Company, by email to the Company’s designated email care@martupi.online        </li>
    </ul>

                </div>
            </section>
           
        

            <!-- ============================================-->
            <!-- <section> begin ============================-->
            <section class="text-center py-0">
                <div class="">
                    <div class="border-top py-3">
                        <div class="row justify-content-center">
                            <div class="col-12 col-md-auto mb-1 mb-md-0">
                                <p class="mb-0">© 2024 SmartUPI All Rights Reserved.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end of .container-->
            </section>
			<!-- <section> close ============================-->
            <!-- ============================================-->
        </main>
        <!-- ===============================================-->
        <!--    End of Main Content-->
        <!-- ===============================================-->

        <!-- ===============================================-->
        <!--    JavaScripts-->
        <!-- ===============================================-->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="https://smartupi.in/home/vendors/@popperjs/popper.min.js"></script>
        <script src="https://smartupi.in/home/vendors/bootstrap/bootstrap.min.js"></script>
        <script src="https://smartupi.in/home/vendors/is/is.min.js"></script>
        <script src="https://smartupi.in/https://polyfill.io/v3/polyfill.min.js?features=window.scroll"></script>
        <script src="https://smartupi.in/home/vendors/fontawesome/all.min.js"></script>
        <script src="https://smartupi.in/home/assets/js/theme.js"></script>
        <script>
          $( document ).ready(function() {
           $('#disclaimer').modal({backdrop: 'static', keyboard: false})  
           $("#disclaimer").modal("show");
          });
        </script>
        <script disable-devtool-auto="" src="https://pay.imb.org.in/Qrcode/disable-devtool.js" data-url="https://www.google.com/"></script> 

    </body>
</html>