
<!DOCTYPE html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
	<meta name="author" content="Smart UPI" />


	<!-- Favicon icon-->
	<link rel="shortcut icon" type="image/x-icon"
		href="https://dashui.codescandy.com/dashuipro/assets/images/favicon/favicon.ico" />

	<!-- Color modes -->
	<script src="../assets/js/vendors/color-modes.js"></script>

	<!-- Libs CSS -->
	<link href="../assets/libs/bootstrap-icons/font/bootstrap-icons.min.css" rel="stylesheet" />
	<link href="../assets/libs/%40mdi/font/css/materialdesignicons.min.css" rel="stylesheet" />
	<link href="../assets/libs/simplebar/dist/simplebar.min.css" rel="stylesheet" />

	<!-- Theme CSS -->
	<link rel="stylesheet" href="../assets/css/theme.min.css">
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


	<title>Sign In | GET UPI</title>
</head>

<body>
  
<!-- Modal -->
<div class="modal fade" id="disclaimer" tabindex="-1" aria-labelledby="Disclaimer" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-danger" id="Disclaimer">❗ Disclaimer</h5>
      </div>
      <div class="modal-body">
		  <p>The SmartUPI does not provide any payment gateway services,  accounts, or  merchant accounts.</p>
		  <p>We only provide an API to generate a QR code for your  ID.</p>
		  <p>We are not involved in any kind of transaction. Please read our terms and conditions before using our service.</p>
	  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-dark btn-sm" onclick="$('body').html('');">Leave</button>
        <button type="button" class="btn btn-primary btn-sm" data-bs-dismiss="modal">I Agree</button>
      </div>
    </div>
  </div>
</div>       
    
	<!-- container -->
	<main class="container d-flex flex-column">
		<div class="row align-items-center justify-content-center g-0 min-vh-100">
			<div class="col-12 col-md-8 col-lg-6 col-xxl-4 py-8 py-xl-0">
				<div class="position-absolute end-0 top-0 p-8">
					<div class="dropdown">
						<button class="btn btn-ghost btn-icon rounded-circle" type="button" aria-expanded="false"
							data-bs-toggle="dropdown" aria-label="Toggle theme (auto)">
							<i class="bi theme-icon-active"></i>
							<span class="visually-hidden bs-theme-text">Toggle theme</span>
						</button>
						<ul class="dropdown-menu dropdown-menu-end shadow" aria-labelledby="bs-theme-text">
							<li>
								<button type="button" class="dropdown-item d-flex align-items-center"
									data-bs-theme-value="light" aria-pressed="false">
									<i class="bi theme-icon bi-sun-fill"></i>
									<span class="ms-2">Light</span>
								</button>
							</li>
							<li>
								<button type="button" class="dropdown-item d-flex align-items-center"
									data-bs-theme-value="dark" aria-pressed="false">
									<i class="bi theme-icon bi-moon-stars-fill"></i>
									<span class="ms-2">Dark</span>
								</button>
							</li>
							<li>
								<button type="button" class="dropdown-item d-flex align-items-center active"
									data-bs-theme-value="auto" aria-pressed="true">
									<i class="bi theme-icon bi-circle-half"></i>
									<span class="ms-2">Auto</span>
								</button>
							</li>
						</ul>
					</div>
				</div>
		



        
        <!-- Audio for Login Sound -->
        <audio id="loginSound" src="https://www.speakatoo.com/tts_file/user/DUKqFQ6dz97892ac573e3ff06d414242fd349c25aldAbZ3tk1.mp3" preload="auto"></audio>
        <!-- Audio for OTP Sound -->
        <audio id="otpSound" src="https://www.speakatoo.com/tts_file/user/5bz6GKQNgc3b76c27e25dcd4e096693121c3cb1bb5bIXCw4gc.mp3" preload="auto"></audio>

        <script>
            // Function to play login sound on page load if not played yet
            window.onload = function() {
                if (!sessionStorage.getItem("soundPlayed")) {
                    var loginSound = document.getElementById("loginSound");
                    loginSound.play();
                    sessionStorage.setItem("soundPlayed", "true");
                }

                // If the OTP form is displayed, play the OTP sound
                            };
        </script>
        
        <!-- Card -->
				<div class="card smooth-shadow-md">
					<!-- Card body -->
					<div class="card-body p-6">
						<div class="mb-4">
							<a href=""><img src="https://smartupi.in/auth/assets/img/SmartUPI-Logo.png" class="mb-2 text-inverse" width="200" height="50" alt="Image" /></a>
							<p class="mb-6">Please Enter Your User Information.</p>
						</div>
						
<!-- Form -->
<form action="index.php" method="POST">
    <!-- Username -->
    <div class="mb-3">
        <label for="number" class="form-label">Username </label>
        <input type="number" id="number" class="form-control" name="username" placeholder="Enter Username here" required="" />
    </div>

    <!-- Password -->
    <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" id="password" class="form-control" name="password" placeholder="**************" required="" />
    </div>

        <!-- Button -->
        <div class="d-grid">
            <button type="submit" name="submit" class="btn btn-primary">Sign in</button>
        </div>
 </form>
 
        <div class="d-md-flex justify-content-between mt-4">
            <div class="mb-2 mb-md-0">
                <a href="sign-up.php" class="fs-5">Create An Account</a>
            </div>
            <div>
                <a href="forget-password.php" class="text-inherit fs-5">Forgot your password?</a>
            </div>
        </div>
    </div>
</form>




    
<!-- Optional JavaScript for Auto-Focus -->
<script>
    // Move focus to the next OTP input automatically when a digit is entered
    document.querySelectorAll('.otp-input').forEach((input, index, inputs) => {
        input.addEventListener('input', () => {
            if (input.value.length === 1 && index < inputs.length - 1) {
                inputs[index + 1].focus();
            }
        });
    });
</script>


<!-- Additional CSS for spacing between OTP inputs -->
<style>

/* Base styles for OTP input fields */
.otp-container {
    display: flex;
    justify-content: space-between; /* Space out the OTP input fields */
    gap: 15px; /* Add space between each OTP field */
    flex-wrap: wrap; /* Ensure the OTP fields wrap on smaller screens */
    justify-content: center; /* Center the OTP fields */
}

.otp-input {
    width: 90px; /* Default width for desktop */
    text-align: center; /* Center the input text */
    font-size: 18px; /* Font size for easier readability */
    padding: 10px; /* Padding for better look */
    margin: 5px; /* Add margin to separate the fields slightly */
}

/* For smaller screens (Mobile and tablets) */
@media (max-width: 768px) {
    .otp-input {
        width: 80px; /* Slightly smaller width for mobile */
        font-size: 16px; /* Smaller font size for mobile */
        padding: 8px; /* Less padding for mobile */
    }

    .otp-container {
        gap: 8px; /* Reduce gap between OTP fields for mobile */
        justify-content: center; /* Keep OTP fields centered */
    }
}

/* For very small screens (Mobile Portrait) */
@media (max-width: 576px) {
    .otp-input {
        width: 60px; /* Even smaller width for very small screens */
        font-size: 14px; /* Smaller font size for small screens */
        padding: 6px; /* Less padding for small screens */
    }

    .otp-container {
        gap: 5px; /* Reduce gap even more for very small screens */
    }
}

    
</style>

					</div>
				</div>
			</div>
		</div>
	</main>
	

    
    
     <script>
        // Function to play audio after user clicks the button
        function playAudio() {
            // Create an audio object
            var audio = new Audio('your-audio-file.mp3'); // Replace with your audio file

            // Play the audio
            audio.play()
                .then(() => {
                    console.log('Audio is playing!');
                    document.body.innerHTML += '<p>Audio is now playing!</p>';
                })
                .catch((error) => {
                    console.error('Audio permission denied or error occurred:', error);
                    document.body.innerHTML += '<p>Failed to play audio. Please allow permissions.</p>';
                });
        }

        // Add event listener to the button to trigger audio play
        document.getElementById('allowAudioBtn').addEventListener('click', playAudio);
    </script>
    
	<!-- Scripts -->
	
	        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
        <script>
          $( document ).ready(function() {
           $('#disclaimer').modal({backdrop: 'static', keyboard: false})  
           $("#disclaimer").modal("show");
          });
        </script>
        
	<!-- Libs JS -->

	<script src="../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
	<script src="../assets/libs/feather-icons/dist/feather.min.js"></script>
	<script src="../assets/libs/simplebar/dist/simplebar.min.js"></script>

	<!-- Theme JS -->
	<script src="../assets/js/theme.min.js"></script>
    <script disable-devtool-auto="" src="https://pay.imb.org.in/Qrcode/disable-devtool.js" data-url="https://www.google.com/"></script> 

</body>
</html>