
<!DOCTYPE html>
<html lang="en-US" dir="ltr">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>SmartUPI -  Dynamic QR Code Generator API</title>
    <link rel="icon" type="image/png" href="https://smartupi.in/auth/assets/img/SmartUPI-Small-Logo.png" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&amp;family=Volkhov:wght@700&amp;display=swap" rel="stylesheet" />
    <link href="https://smartupi.in/home/assets/css/theme.css" rel="stylesheet" />
<style type="text/css">
.plan-box {
    background-color: transparent;
    box-shadow: 0px 1px 15px 1px rgb(69 65 78 / 8%);
    border: none;
}  

.btn-check:focus + .btn-primary, .btn-primary:focus {
    color: #FFFEFE;
    background-color: #066ede;
    border-color: #066ede;
}

.btn-primary:hover {
    color: #FFFEFE;
    background-color: #066ede;
    border-color: #066ede;
}

.btn-primary {
    color: #FFFEFE;
    background-color: #007bff;
    border-color: #007bff;
}
.text-primary {
    color: #007bff !important;
}
.btn-check:checked + .btn-outline-primary, .btn-check:active + .btn-outline-primary, .btn-outline-primary:active, .btn-outline-primary.active, .btn-outline-primary.dropdown-toggle.show {
    color: #FFFEFE;
    background-color: #007bff;
    border-color: #007bff;
}
.btn-outline-primary:hover {
    color: #FFFEFE;
    background-color: #007bff;
    border-color: #007bff;
}
.btn-outline-primary {
    color: #007bff;
    border-color: #007bff;
}
.modal-content {
    border-radius: 0.5rem;
}

.text-dark {
    color: #000000 !important;
}

.btn-dark {
    color: #FFFEFE;
    background-color: #000000;
    border-color: #000000;
}

.bg-dark {
    color: #FFFEFE !important;
    background-color: #000000 !important;
    border-color: #000000 !important;
}
</style>    
</head>

<body>
<!-- Modal -->
<div class="modal fade" id="disclaimer" tabindex="-1" aria-labelledby="Disclaimer" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-danger" id="Disclaimer">❗ Disclaimer</h5>
      </div>
      <div class="modal-body">
		  <p>The SmartUPI does not provide any payment gateway services,  accounts, or  merchant accounts.</p>
		  <p>We only provide an API to generate a QR code for your  ID.</p>
		  <p>We are not involved in any kind of transaction. Please read our terms and conditions before using our service.</p>
	  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-dark btn-sm" onclick="$('body').html('');">Leave</button>
        <button type="button" class="btn btn-primary btn-sm" data-bs-dismiss="modal">I Agree</button>
      </div>
    </div>
  </div>
</div>        
        <!-- ===============================================-->
        <!--    Main Content-->
        <!-- ===============================================-->
        <main class="main" id="top">
            <nav class="navbar navbar-expand-lg navbar-light sticky-top" data-navbar-on-scroll="data-navbar-on-scroll">
                <div class="container">
                    <a class="navbar-brand" href="index"><img src="https://smartupi.in/auth/assets/img/SmartUPI-Logo.png" height="31" alt="logo" /></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"> </span>
                    </button>
                    <div class="collapse navbar-collapse border-top border-lg-0 mt-4 mt-lg-0" id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto">
                            <li class="nav-item"><a class="nav-link" aria-current="page" href="index">Home</a></li>
                            <li class="nav-item"><a class="nav-link" aria-current="page" href="terms_conditions">Terms & Conditions</a></li>
                            <li class="nav-item"><a class="nav-link" aria-current="page" href="privacy_policy">Privacy Policy</a></li>
                            <li class="nav-item"><a class="nav-link" aria-current="page" href="refund_policy">Refund Policy</a></li>
                            <li class="nav-item"><a class="nav-link" aria-current="page" href="account_access_policy">AA Policy</a></li>
                        </ul>
                        <div class="d-flex ms-lg-4">
						  <a class="btn btn-info" href="auth/index">Login</a>
						</div>
                    </div>
                </div>
            </nav>            <section class="pt-4 pb-0 mb-0">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-md-12 text-center py-5">
                            <h1 class="mb-4 fs-9 fw-bold">Refund Policy</h1>
							<p>We are on a mission to make the web a better place. The following terms, as well as our Policy, Terms of Service and Account Access Policy, apply to all users.. Last Update: Nov 08, 2023</p>
                        </div>
					</div>
                </div>
            </section>
			
            <section class="pt-0"> 
                <div class="container py-5">
     <h2 class="mb-4"><strong class="font-bold text-3xl">PRODUCT PRICING</strong></h2>
<p>
    The contract takes effect from the date of service activation for the initial term ("Initial Term") of one (1) year following the end of the initial 3-day trial period for all listed packages. At the end of this Initial Term, the
    contract is automatically renewed via the Auto-renewal system if selected by the user for the same term.
</p>
<p>
    The service fee amount, which includes (Starter, Startup, Business, Business +) packages, is payable upon signing the contract via sign-up to the website. Payment for the service will be made manually by the user based on the chosen
    monthly or quarterly prepaid plan.
</p>
<p>The sums due to SmartUPI do not include the cost of the Internet connection, which remains the Customer's responsibility.</p>
<p>
    The SaaS Service is provided with subject to the Customer's acceptance of these Terms Of Use at smartupi.online/terms_conditions. The latter is deemed to have accepted the Data Protection Policy by means of a clickable "Buy Now" button when
    ordering the Service.
</p>
<p>These T&amp;Cs govern the contractual relationship between the Company and the Customer who accept them without reservation.</p>
<ul></ul>
<h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">ACCOUNT TERMINATION</strong></h2>
<p>
    Subject to the provisions of public order, SmartUPI and the Customer may terminate the Contract in the event of serious misconduct, not remedied within thirty (30) days of formal notice, subject to notifying the decision to both
    parties, by registered letter along with the acknowledgment of misconducts or TOS violations receipt.
</p>
<p>Constitutes serious misconducts may include:</p>
<ul class="mt-2 mb-2" style="list-style-position: outside; list-style-type: disc;">
    <li>Non-payment of an invoice</li>
    <li>The violation by the Customer of the scope of the rights granted to him under the contract</li>
    <li>An attempt of intrusion or attack on the integrity of the Site by the Customer</li>
</ul>
<p>
    Furthermore, the defaulting Party undertakes to compensate the other Party for all proven damages that it has suffered and resulting from the termination of the contract due to a breach by the defaulting Party of its contractual
    obligations.
</p>
<h2 class="mb-4 mt-4"><strong class="font-bold text-3xl">REFUND CONDITIONS</strong></h2>
<p>In general, we are not offering a refund for our SAAS Service packages, but in some conditions, the user may get a partial or full refund.</p>
<ul class="mt-2 mb-2" style="list-style-position: outside; list-style-type: disc;">
    <li>If you accidentally purchased the subscription and wanted a refund.</li>
    <li>To claim your refund, you have to contact us at care@smartupi.in within 24 hours.</li>
    <li>The final decision will be of smartupi.online, and no claims shall be made against it.</li>
    <li>To be eligible for a refund, the user has to email with "Subscription Details and Cancellation Reason" within a day.</li>
    <li>The refund may take up to 30 days.</li>
</ul>




                </div>
            </section>
           
        

            <!-- ============================================-->
            <!-- <section> begin ============================-->
            <section class="text-center py-0">
                <div class="">
                    <div class="border-top py-3">
                        <div class="row justify-content-center">
                            <div class="col-12 col-md-auto mb-1 mb-md-0">
                                <p class="mb-0">© 2024 SmartUPI All Rights Reserved.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end of .container-->
            </section>
			<!-- <section> close ============================-->
            <!-- ============================================-->
        </main>
        <!-- ===============================================-->
        <!--    End of Main Content-->
        <!-- ===============================================-->

        <!-- ===============================================-->
        <!--    JavaScripts-->
        <!-- ===============================================-->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="https://smartupi.in/home/vendors/@popperjs/popper.min.js"></script>
        <script src="https://smartupi.in/home/vendors/bootstrap/bootstrap.min.js"></script>
        <script src="https://smartupi.in/home/vendors/is/is.min.js"></script>
        <script src="https://smartupi.in/https://polyfill.io/v3/polyfill.min.js?features=window.scroll"></script>
        <script src="https://smartupi.in/home/vendors/fontawesome/all.min.js"></script>
        <script src="https://smartupi.in/home/assets/js/theme.js"></script>
        <script>
          $( document ).ready(function() {
           $('#disclaimer').modal({backdrop: 'static', keyboard: false})  
           $("#disclaimer").modal("show");
          });
        </script>
        <script disable-devtool-auto="" src="https://pay.imb.org.in/Qrcode/disable-devtool.js" data-url="https://www.google.com/"></script> 

    </body>
</html>